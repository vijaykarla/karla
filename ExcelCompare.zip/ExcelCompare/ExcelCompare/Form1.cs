﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using Microsoft.Office.Interop.Excel;
using System.Runtime.InteropServices;
using System.IO;

namespace ExcelCompare
{
    public partial class Form1 : Form
    {
        int RNFSheet = 2;
        int RNFileColumn = 4;
        int RNPathColumn = 7;
        int RNVersionColumn = 6;

        int CASheet = 1;
        int CAFileColumn = 1;
        int CAPathColumn = 2;
        int CAVersionColumn = 3;

        string RNFile = string.Empty;
        string CAFile = string.Empty;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnRN_Click(object sender, EventArgs e)
        {
            DialogResult result = openFileDialog1.ShowDialog();
            if (result == DialogResult.OK) // Test result.
            {
            }
            Console.WriteLine(result); // <-- For d
        }
        
        private void btnCA_Click(object sender, EventArgs e)
        {
            DialogResult result = openFileDialog2.ShowDialog();
            if (result == DialogResult.OK) // Test result.
            {
            }
            Console.WriteLine(result); // <-- For d
        }

        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {
            RNFile = openFileDialog1.FileName;
        }
      

        private void openFileDialog2_FileOk(object sender, CancelEventArgs e)
        {
            CAFile = openFileDialog2.FileName;
        }

        private void btnCompare_Click(object sender, EventArgs e)
        {
            CompareFiles();
        }

        public void CompareFiles()
        {
            List<FileItem> RNItems = new List<FileItem>();
            List<FileItem> CAItems = new List<FileItem>();

            Microsoft.Office.Interop.Excel.Application _excelApp = new Microsoft.Office.Interop.Excel.Application();
            _excelApp.Visible = false;           

            //open the workbook
            Workbook workbook = _excelApp.Workbooks.Open(RNFile,
                Type.Missing, Type.Missing, Type.Missing, Type.Missing,
                Type.Missing, Type.Missing, Type.Missing, Type.Missing,
                Type.Missing, Type.Missing, Type.Missing, Type.Missing,
                Type.Missing, Type.Missing);

            //select the first sheet        
            Worksheet worksheet = (Worksheet)workbook.Worksheets[RNFSheet];

            //find the used range in worksheet
            Range excelRange = worksheet.UsedRange;

            //get an object array of all of the cells in the worksheet (their values)
            object[,] valueArray = (object[,])excelRange.get_Value(
                        XlRangeValueDataType.xlRangeValueDefault);

            //access the cells
           
            for (int row = 1; row <= worksheet.UsedRange.Rows.Count; ++row)
            {
                if (valueArray[row, RNFileColumn] != null && !string.IsNullOrWhiteSpace(valueArray[row, RNFileColumn].ToString()))
                {
                    string fileName = valueArray[row, RNFileColumn].ToString();
                    if (fileName.IndexOfAny(Path.GetInvalidFileNameChars()) < 0 && fileName.Contains("."))
                    {
                        FileItem RNItem = new FileItem();
                        RNItem.FileName = fileName;
                        if (valueArray[row, RNPathColumn] != null && !string.IsNullOrWhiteSpace(valueArray[row, RNPathColumn].ToString()))
                        {
                            RNItem.FilePath = valueArray[row, RNPathColumn].ToString();
                        }
                        if (valueArray[row, RNVersionColumn] != null && !string.IsNullOrWhiteSpace(valueArray[row, RNVersionColumn].ToString()))
                        {
                            RNItem.FileVersion = valueArray[row, RNVersionColumn].ToString();
                        }
                        int colorNumber = System.Convert.ToInt32(((Range)worksheet.Cells[row, RNFileColumn]).Interior.Color);
                        Color color = System.Drawing.ColorTranslator.FromOle(colorNumber);
                        RNItem.CellColor = color;
                        RNItems.Add(RNItem);
                    }
                }
               
            }

            //clean up stuffs
            workbook.Close(false, Type.Missing, Type.Missing);
            Marshal.ReleaseComObject(workbook);

            _excelApp.Quit();
            Marshal.FinalReleaseComObject(_excelApp);

            //======================================================================

            _excelApp = new Microsoft.Office.Interop.Excel.Application();
            _excelApp.Visible = false;

            //open the workbook
            workbook = _excelApp.Workbooks.Open(CAFile,
                Type.Missing, Type.Missing, Type.Missing, Type.Missing,
                Type.Missing, Type.Missing, Type.Missing, Type.Missing,
                Type.Missing, Type.Missing, Type.Missing, Type.Missing,
                Type.Missing, Type.Missing);

            //select the first sheet        
            worksheet = (Worksheet)workbook.Worksheets[CASheet];

            //find the used range in worksheet
            excelRange = worksheet.UsedRange;

            //get an object array of all of the cells in the worksheet (their values)
            valueArray = (object[,])excelRange.get_Value(
                        XlRangeValueDataType.xlRangeValueDefault);

            //access the cells

            for (int row = 1; row <= worksheet.UsedRange.Rows.Count; ++row)
            {
                if (valueArray[row, CAFileColumn] != null && !string.IsNullOrWhiteSpace(valueArray[row, CAFileColumn].ToString()))
                {
                    string fileName = valueArray[row, CAFileColumn].ToString();
                    if (fileName.IndexOfAny(Path.GetInvalidFileNameChars()) < 0 && fileName.Contains("."))
                    {
                        FileItem CAItem = new FileItem();
                        CAItem.FileName = fileName;
                        if (valueArray[row, CAPathColumn] != null && !string.IsNullOrWhiteSpace(valueArray[row, CAPathColumn].ToString()))
                        {
                            CAItem.FilePath = valueArray[row, CAPathColumn].ToString();
                        }
                        if (valueArray[row, CAVersionColumn] != null && !string.IsNullOrWhiteSpace(valueArray[row, CAVersionColumn].ToString()))
                        {
                            CAItem.FileVersion = valueArray[row, CAVersionColumn].ToString();
                        }
                        int colorNumber = System.Convert.ToInt32(((Range)worksheet.Cells[row, CAFileColumn]).Interior.Color);
                        Color color = System.Drawing.ColorTranslator.FromOle(colorNumber);
                        CAItem.CellColor = color;
                        CAItems.Add(CAItem);
                    }
                }

            }

            //clean up stuffs
            workbook.Close(false, Type.Missing, Type.Missing);
            Marshal.ReleaseComObject(workbook);

            _excelApp.Quit();
            Marshal.FinalReleaseComObject(_excelApp);

            createDoc("output2.xlsx", RNItems, CAItems);
        }

        public void createDoc(string outFile, List<FileItem> RNItems, List<FileItem> CAItems)
        {
            Microsoft.Office.Interop.Excel.Application app = null;
            Microsoft.Office.Interop.Excel.Workbook workbook = null;
            Microsoft.Office.Interop.Excel.Worksheet worksheet = null;
            Microsoft.Office.Interop.Excel.Range workSheet_range = null;
            try
            {
                app = new Microsoft.Office.Interop.Excel.Application();
                app.Visible = false;
                workbook = app.Workbooks.Add(1);
                worksheet = (Microsoft.Office.Interop.Excel.Worksheet)workbook.Sheets[1];

                worksheet.Cells[1, 1] = "No";
                worksheet.Cells[1, 2] = "File";
                worksheet.Cells[1, 3] = "Version";
                worksheet.Cells[1, 4] = "Path";
                worksheet.Cells[1, 5] = "Comment";

                CompareItems(worksheet, workSheet_range, RNItems, CAItems);

                string location = System.Reflection.Assembly.GetEntryAssembly().Location;
                int lastIndex = location.LastIndexOf("\\");
                location = location.Remove(lastIndex);
                string outFilePath = Path.Combine(location, outFile);

                if (File.Exists(outFilePath))
                {
                    try
                    {
                        File.Delete(outFilePath);
                    }
                    catch { }
                }
                workbook.SaveAs(outFilePath);
            }
            catch (Exception e)
            {
                Console.Write("Error");
            }
            finally
            {
                //clean up stuffs
                workbook.Close(false, Type.Missing, Type.Missing);
                Marshal.ReleaseComObject(workbook);

                app.Quit();
                Marshal.FinalReleaseComObject(app);

            }

        }

        private void CompareItems(Microsoft.Office.Interop.Excel.Worksheet worksheet, Microsoft.Office.Interop.Excel.Range workSheet_range, List<FileItem> RNItems, List<FileItem> CAItems)
        {
            int rowIndex = 2;
            foreach (FileItem RNItem in RNItems)
            {
                addData(worksheet, workSheet_range, rowIndex, 1, (rowIndex - 1).ToString(), RNItem.CellColor);
                addData(worksheet, workSheet_range, rowIndex, 2, RNItem.FileName, RNItem.CellColor);
                addData(worksheet, workSheet_range, rowIndex, 3, RNItem.FileVersion, RNItem.CellColor);
                addData(worksheet, workSheet_range, rowIndex, 4, RNItem.FileName, RNItem.CellColor);

                string comment = string.Empty;

                FileItem CAItem = CAItems.FirstOrDefault(element => element.FileName.Equals(RNItem.FileName.Trim(), StringComparison.CurrentCultureIgnoreCase));
                if (CAItem != null)
                {
                    if (RNItem.FileVersion.Trim() != CAItem.FileVersion.Trim())
                        comment = "Version";
                }
                else
                {
                    comment = "File";
                }
                addData(worksheet, workSheet_range, rowIndex, 5, comment, RNItem.CellColor);
                rowIndex++;
                if (rowIndex == 250)
                    break;
            }
        }

        public void addData(Microsoft.Office.Interop.Excel.Worksheet worksheet, Microsoft.Office.Interop.Excel.Range workSheet_range, int row, int col, string data, Color color)
        {
            worksheet.Cells[row, col] = data;
            workSheet_range = (Range)worksheet.Cells[row-1, col];
            workSheet_range.Borders.Color = System.Drawing.Color.Black.ToArgb();
            workSheet_range.Cells[row, col].Interior.Color = color;
        }  
    }

    public class FileItem
    {
        public string FileName { get; set; }
        public string FilePath { get; set; }
        public string FileVersion { get; set; }
        public Color CellColor { get; set; }
    }
}
