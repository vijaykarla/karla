﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DataTableDisplay
{
    public partial class DataDisplay : System.Web.UI.Page
    {
        private static string dbConnection = @"Server=ttt;Database=peptrack;User ID=xxx;Password=yyy";
        public string message;
        protected void Page_Load(object sender, EventArgs e)
        {
            lblMessage.Visible = false;
            getWhileLoopData();
        }

        public void getWhileLoopData()
        {
            string htmlStr = "";
            int trackId = 0;
            int pageSize = 1000;
            int pageIndex = 0;
            int.TryParse(Request.QueryString["trackid"], out trackId);
            int.TryParse(Request.QueryString["pagesize"], out pageSize);
            int.TryParse(Request.QueryString["pageindex"], out pageIndex);
            if(pageIndex < 0)
                pageIndex = 0;
            if (pageSize > 1000)
            {
                message = "Maximum of 1000 records allowed";
                pageSize = 1000;
            }
            if (trackId < 1)
                message = "TrackID is missing or invalid";
            if (pageSize < 1)
                message = "PageSize is missing or invalid";

            if (pageSize > 0 && trackId > 0)
            {
                int startRow = pageSize * pageIndex + 1;
                int endRow = startRow * pageSize;

                string sqlQuery = "SELECT LocationId, DATEADD(mi, 330, EVENTTIME) EventTime, Latitude, Longitude, GroundSpeed, CASE WHEN EVENTTYPEID = 1 THEN 'G_PING' WHEN  EVENTTYPEID = 2 THEN 'REBOOT' ELSE  'OTHER' END AS EventType FROM (SELECT ROW_NUMBER() OVER (ORDER BY LocationId DESC) AS RowNum, * FROM dbo.Location WHERE TrackId = " + trackId + ") AS RowConstrainedResult WHERE RowNum >= " + startRow + " AND RowNum < " + endRow + " ORDER BY RowNum";

                SqlConnection thisConnection = new SqlConnection(dbConnection);
                SqlCommand thisCommand = thisConnection.CreateCommand();
                thisCommand.CommandText = sqlQuery;
                thisConnection.Open();
                SqlDataReader reader = thisCommand.ExecuteReader();

                while (reader.Read())
                {
                    string LocationId = reader["LocationId"].ToString();
                    string EventTime = Convert.ToDateTime(reader["EventTime"]).ToString("dd/MM/yyyy h:mm:ss tt");
                    string Latitude = reader["Latitude"].ToString();
                    string Longitude = reader["Longitude"].ToString();
                    string GroundSpeed = reader["GroundSpeed"].ToString();
                    string EventType = reader["EventType"].ToString();

                    htmlStr += "<tr><td>" + LocationId + "</td><td>" + EventTime + "</td><td>" + Latitude + "</td><td>" + Longitude + "</td><td>" + GroundSpeed + "</td><td>" + EventType + "</td></tr>";
                }

                thisConnection.Close();
            }
            if (!string.IsNullOrWhiteSpace(message))
            {
                lblMessage.Visible = true;
                lblMessage.Text = message;
            }
            dataHolder.Text = htmlStr;
        }
    }
}